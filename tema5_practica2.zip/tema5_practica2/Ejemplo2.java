package tema5_practica2;

public class Ejemplo2 {

	public static void main(String[] args) {
		System.out.println("Si se esperaba algo aqu�, lo siento por la decepci�n, lo importante aqu� es saber usar Git y GitHub");

	}

}
