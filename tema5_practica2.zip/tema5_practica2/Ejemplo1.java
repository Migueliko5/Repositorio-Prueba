package tema5_practica2;

public class Ejemplo1 {

	public static void main(String[] args) {
		System.out.println("Este programa es de ejemplo para ser subido a GitHub");

	}

}
